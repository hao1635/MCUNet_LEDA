from models.taming.modules.losses.vqperceptual import DummyLoss

